CREATE PROCEDURE SP_ObtenerAdjudicaciones
AS
BEGIN
    SELECT *
    FROM Adjudicaciones
END
