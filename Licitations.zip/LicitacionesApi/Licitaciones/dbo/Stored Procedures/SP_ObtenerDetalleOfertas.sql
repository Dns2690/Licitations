﻿CREATE PROCEDURE [dbo].[SP_ObtenerDetalleOfertas]
AS
BEGIN
    SELECT *
    FROM DetalleOfertas
END
