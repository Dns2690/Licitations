﻿CREATE PROCEDURE SP_ObtenerDetallesLicitaciones
AS
BEGIN
    SELECT *
    FROM DetalleLicitaciones
END