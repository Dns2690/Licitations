﻿CREATE PROCEDURE SP_ObtenerLicitaciones
AS
BEGIN
    SELECT *
    FROM Licitaciones
END