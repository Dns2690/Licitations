﻿CREATE PROCEDURE SP_ObtenerPremium
AS
BEGIN
    SELECT *
    FROM Suscripciones
END
