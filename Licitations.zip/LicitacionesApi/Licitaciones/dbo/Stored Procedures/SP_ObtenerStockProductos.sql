﻿CREATE PROCEDURE [dbo].[SP_ObtenerStockProductos]
AS
BEGIN
    SELECT *
    FROM StockProductos
END