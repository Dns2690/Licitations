﻿CREATE PROCEDURE SP_ObtenerUsuarios
AS
BEGIN
    SELECT *
    FROM Usuarios
END