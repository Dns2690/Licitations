﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebAppUI.Controllers
{
    public class EntregasController : Controller
    {
        // GET: Entregas
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Entregas()
        {
            return View();
        }
    }
}